//This is a work of Mukram Hafiz and Harith Hilman from group Cendol of DSWE3 SEM3
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Class representing the start screen of the application
public class startScreen {

    private JPanel startPanel;
    private JButton startButton; // Button to start the main application
    private JLabel pageImage; // Label to display an image on the start screen
    private JButton exit; // Button to exit the application

    // Constructor to initialize the start screen functionality
    public startScreen() {
        // Set the background image for the start screen
        ImageIcon icon = new ImageIcon("gambling/pageimage.jpg");
        pageImage.setIcon(icon);

        // ActionListener for the startButton to start the main application
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.begingamba();
                // Close the JFrame
                ((JButton)e.getSource()).getTopLevelAncestor().setVisible(false);
            }
        });
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startScreen.close();
            }
        });
    }
    public static void begin() {
        // Create and display the JFrame for the start screen on the event dispatch thread
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("WELCOME TO GMI");
            frame.setContentPane(new startScreen().startPanel);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
        });
    }
    // Method to close the application
    public static void close(){
        System.exit(0);
    }
    // Main method to start the application by displaying the start screen
    public static void main(String[] args) {
        startScreen.begin();
    }
}
