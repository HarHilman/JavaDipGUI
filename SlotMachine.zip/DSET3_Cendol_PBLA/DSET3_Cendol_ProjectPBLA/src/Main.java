//This is a work of Mukram Hafiz and Harith Hilman from group Cendol of DSWE3 SEM3
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Random;

//Main class representing slot machine system
public class Main {
    //GUI Components declaration
    private JButton gambagamba; //Button to start/stop the system
    // Label for displaying images
    private JPanel slots;
    private JLabel image5;
    private JLabel image4;
    private JLabel image1;
    private JLabel image2;
    private JLabel image3;
    private JLabel TITLE;
    // Textfield to enter bet amount
    private JTextField Entermoneybutton;
    private JPanel imagepanel;
    private JPanel balancepanel;
    private JLabel moneyLabel; // Label to display player's current balance
    private JLabel BalanceLabel;
    private JLabel winlabel; // Label to display win or loss information
    private JButton REJUICEButton; // Button to add balance
    private JButton quit; // Button to quit the game
    private JLabel betAmount; // Label to display the betting amount
    private JButton WITHDRAWButton; // Button to withdraw money
    private ImageIcon[] images; // Array to store images for the slot machine
    private Timer[] imageSwitchTimers; // Timers to switch images at different intervals
    private boolean isSpinning = false; // Flag to check if the slot machine is currently spinning
    private double playerMoney = 0; // Initialize with an initial balance


    // Constructor to initialize the main functionality
    public Main() {
        // Load image for slot machine
        ImageIcon firstImage = new ImageIcon("gambling/b.png");
        ImageIcon secondImage = new ImageIcon("gambling/a.png");
        ImageIcon thirdImage = new ImageIcon("gambling/c.png");

        images = new ImageIcon[] {
                firstImage,
                secondImage,
                thirdImage
        };

        // Set the initial images on the image buttons
        for (JLabel imageLabel: new JLabel[] {
                image1,
                image2,
                image3,
                image4,
                image5
        }) {
            imageLabel.setIcon(images[0]);
        }

        // Create timers for each image button to switch images at different intervals
        imageSwitchTimers = new Timer[5];
        int baseDelay = 50; // Adjust this value to change the overall speed

        for (int i = 0; i < imageSwitchTimers.length; i++) {
            int timerDelay = baseDelay * (i + 1); // Adjust the multiplier to make it faster or slower
            int finalI = i;
            imageSwitchTimers[i] = new Timer(timerDelay, e -> {
                int nextImageIndex = new Random().nextInt(images.length);
                JLabel imageLabel = new JLabel[] {
                        image1,
                        image2,
                        image3,
                        image4,
                        image5
                } [finalI];
                imageLabel.setIcon(images[nextImageIndex]);
            });
        }

        // Add ActionListener to gambagamba button to start/stop the slot machine animation
        gambagamba.addActionListener(e -> {
            if (isSpinning) {
                // Stop the animation when gambagamba button is pressed
                for (Timer timer: imageSwitchTimers) {
                    gambagamba.setText("START");
                    timer.stop();
                }

                // Check for winning conditions
                int[] currentImages = new int[5];
                for (int i = 0; i < 5; i++) {
                    JLabel imageLabel = new JLabel[] {
                            image1,
                            image2,
                            image3,
                            image4,
                            image5
                    }[i];
                    int imageIndex = Arrays.asList(images).indexOf(imageLabel.getIcon());
                    currentImages[i] = imageIndex;
                }

                // Check for wins with 2, 3, or 4 matching images
                int maxConsecutiveMatches = 1;
                for (int i = 0; i < currentImages.length; i++) {
                    int count = 1;
                    for (int j = i + 1; j < currentImages.length; j++) {
                        if (currentImages[i] == currentImages[j]) {
                            count++;
                        } else {
                            break;
                        }
                    }
                    if (count > maxConsecutiveMatches) {
                        maxConsecutiveMatches = count;
                    }
                }

                // Define winning conditions and payouts based on the number of matches
                if (maxConsecutiveMatches >= 2) {
                    double payout = 0.00;
                    switch (maxConsecutiveMatches) {
                        case 3:
                            int betAmount = Integer.parseInt(Entermoneybutton.getText());
                            payout = 0.3 * betAmount; // Payout for 3 matches
                            break;
                        case 4:
                            betAmount = Integer.parseInt(Entermoneybutton.getText());
                            payout = 2 * betAmount; // Payout for 4 matches
                            break;
                        case 5:
                            betAmount = Integer.parseInt(Entermoneybutton.getText());
                            payout = 15 * betAmount;
                    }
                    playerMoney += payout;
                    moneyLabel.setText("$" + String.format("%.2f", playerMoney));
                    winlabel.setText("[  +$" + String.format("%.2f  ]", payout));
                }
            } else {
                // Deduct the betting amount
                String betAmountText = Entermoneybutton.getText();
                try {
                    if (!betAmountText.isEmpty()) {
                        double betAmount = Double.parseDouble(betAmountText);
                        if (betAmount > 0 && betAmount <= playerMoney) {
                            playerMoney -= betAmount;
                            moneyLabel.setText("$" + String.format("%.2f", playerMoney));
                            winlabel.setText("[ -$" + String.format("%.2f  ]", betAmount));
                        } else {
                            JOptionPane.showMessageDialog(null, "Insufficient funds");
                            return; // Don't start the animation if the bet amount is invalid
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Enter a bet amount");
                        return; // Don't start the animation if the bet amount is empty
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid bet amount. Please enter a valid amount.");
                    return; // Don't start the animation if the bet amount is not a valid number
                }

                // Start the animation to switch images like a slot machine
                for (Timer timer: imageSwitchTimers) {
                    gambagamba.setText("STOP");
                    timer.start();
                }
            }
            isSpinning = !isSpinning;
        });

        // ActionListener for REJUICEButton to add balance
        REJUICEButton.addActionListener(e -> {
            showAddBalancePopup();
        });

        // ActionListener for quit button to exit the game
        quit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startScreen.begin();
                ((JButton)e.getSource()).getTopLevelAncestor().setVisible(false);
            }
        });
        // ActionListener for WITHDRAWButton to withdraw money
        WITHDRAWButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String balanceMessage = "Your current balance is $" + String.format("%.2f", playerMoney) + "\nDo you want to withdraw?";
                int option = JOptionPane.showConfirmDialog(null, balanceMessage, "Withdraw Balance", JOptionPane.YES_NO_OPTION);

                if (option == JOptionPane.YES_OPTION){
                    JOptionPane.showMessageDialog(null, "Withdrawal successful. Your balance of $" + String.format("%.2f", playerMoney) + " has been withdrawn.");
                    playerMoney = 0; // Reset the balance to 0
                    moneyLabel.setText("$" + String.format("%.2f", playerMoney));
                }
            }
        });
    }

    // Method to show a popup for adding balance
    void showAddBalancePopup() {
        String input = JOptionPane.showInputDialog("Enter the amount to add to your balance:");
        try {
            double amount = Double.parseDouble(input);
            if (amount > 0) {
                playerMoney += amount;
                moneyLabel.setText("$" + String.format("%.2f", playerMoney));
            } else {
                JOptionPane.showMessageDialog(null, "Invalid amount. Cannot be negative.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
        }
    }

    public static void begingamba() {

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Gamba Maschine Intuition");
            frame.setContentPane(new Main().slots);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);

        });
    }
}